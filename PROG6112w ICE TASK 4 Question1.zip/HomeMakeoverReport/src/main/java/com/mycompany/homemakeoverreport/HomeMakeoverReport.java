/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.homemakeoverreport;

/**
 *
 * @author prude
 */
public class HomeMakeoverReport {

    public static void main(String[] args) {
        // Single-dimensional array for months
        String[] months = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN"};

        // Two-dimensional array for makeover jobs: [Bathrooms, Kitchens, Garden]
        int[][] makeovers = {
            {8, 2, 5}, // January
            {7, 4, 5}, // February
            {5, 5, 2}, // March
            {2, 2, 3}, // April
            {7, 7, 9}, // May
            {7, 8, 5}  // June
        };

        // 1. Display Header and Table
        System.out.println("--------------------------------------------------");
        System.out.println("HOME MAKEOVER REPORT");
        System.out.println("--------------------------------------------------");
        System.out.printf("%-10s %-12s %-12s %-12s\n", "", "Bathrooms", "Kitchens", "Garden");

        // Loop through rows to display monthly job details
        for (int i = 0; i < months.length; i++) {
            System.out.printf("%-10s %-12d %-12d %-12d\n", 
                months[i], makeovers[i][0], makeovers[i][1], makeovers[i][2]);
        }

        // 2. Display Monthly Totals Section
        System.out.println("--------------------------------------------------");
        System.out.println("MONTHLY TOTALS");
        System.out.println("--------------------------------------------------");

        // Array to store totals for each month
        int[] monthlyTotals = new int[months.length];

        // Loop to calculate and display total makeover jobs per month
        for (int i = 0; i < months.length; i++) {
            // Sum the 3 categories for the current month
            monthlyTotals[i] = makeovers[i][0] + makeovers[i][1] + makeovers[i][2];

            // Determine if total is 15 or greater to attach stars
            String stars = "";
            if (monthlyTotals[i] >= 15) {
                stars = "***";
            }

            // Print month name, total, and star indicator when applicable
            System.out.printf("%-10s %-5d %-5s\n", months[i], monthlyTotals[i], stars);
        }
        
        System.out.println("--------------------------------------------------");
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usestaff;
import java.util.Scanner;
/**
 *
 * @author prude
 */

// Main class to instantiate and test application
public class UseStaff {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for current staff number
        System.out.print("Enter the current staff number: ");
        int staffNumber = scanner.nextInt();
        scanner.nextLine(); // Clear input buffer

        // Prompt user for location
        System.out.print("Enter the staff hiring location: ");
        String staffLocation = scanner.nextLine();

        // Instantiate StaffHiring object
        StaffHiring staffHiring = new StaffHiring(staffNumber, staffLocation);

        // Print final output report
        staffHiring.printStaffHiring();

        scanner.close();
    }
}
   
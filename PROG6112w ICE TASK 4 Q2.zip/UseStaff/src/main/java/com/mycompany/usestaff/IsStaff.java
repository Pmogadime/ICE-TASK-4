/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.usestaff;

/**
 *
 * @author prude
 */
 // Interface defining required getter methods
public interface IsStaff {
    int getStaffNumber();
    String getStaffLocation();
    String getStaffHiringProcess();
}   

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.usestaff;

/**
 *
 * @author prude
 */
 // Abstract class implementing the iStaff interface
public abstract class Staff implements IsStaff {
    // Member variables for staff details
    private int staffNumber;
    private String staffLocation;

    // Constructor to initialize staff number and location
    public Staff(int staffNumber, String staffLocation) {
        this.staffNumber = staffNumber;
        this.staffLocation = staffLocation;
    }

    // Getter method for staff number
    @Override
    public int getStaffNumber() {
        return staffNumber;
    }

    // Getter method for staff location
    @Override
    public String getStaffLocation() {
        return staffLocation;
    }

    // Abstract method implementation for hiring logic decision
    @Override
    public String getStaffHiringProcess() {
        // Return YES if staff count is under 20, otherwise NO
        if (getStaffNumber() < 20) {
            return "YES";
        } else {
            return "NO";
        }
    }
}   

